package Upper;
use strict;
use Module::Compile -base;

sub pmc_compile { uc }

1;
