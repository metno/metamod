package Demo_Data;
$VERSION = '0.01';

use Filter::Simple;

FILTER { s/say/print/g; }
