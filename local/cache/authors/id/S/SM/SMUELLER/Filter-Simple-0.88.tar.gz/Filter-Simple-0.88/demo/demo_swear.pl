use DemoSwear;

# WARNING: THIS DEMO CONTAINS AND PRODUCES OFFENSIVE LANGUAGE...
















































































my $this = qr/a merde string/;
print #*@%-ing "that merde: $this\n";
print #*@%-ing <<EOS;
 that merde: $this
EOS
$_ = "crappy 123";
s /\d/a/g;
print $_, "\n";
