use DemoRevCat;

my $str = "abc" . q:def:;

print "$str\n";


