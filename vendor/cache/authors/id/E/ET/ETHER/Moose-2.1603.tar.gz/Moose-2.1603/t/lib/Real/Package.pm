package Real::Package;
use strict;
use warnings;

sub foo { }

1;
