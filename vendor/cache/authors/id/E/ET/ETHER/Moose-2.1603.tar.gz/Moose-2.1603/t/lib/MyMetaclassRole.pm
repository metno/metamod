package MyMetaclassRole;
use Moose::Role;

1;
