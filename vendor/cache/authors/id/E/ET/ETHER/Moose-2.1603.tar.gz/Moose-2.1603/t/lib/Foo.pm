package Foo;
use Moose;

has 'bar' => (is => 'rw');

1;
