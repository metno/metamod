package TestAppEncodingSetInConfig;
use Moose;

use Catalyst qw/ConfigLoader/;

extends 'Catalyst';

__PACKAGE__->setup;

1;
