package TestAppEncoding;
use strict;
use warnings;
use base qw/Catalyst/;
use Catalyst;

__PACKAGE__->config(name => __PACKAGE__);
__PACKAGE__->setup;

1;

