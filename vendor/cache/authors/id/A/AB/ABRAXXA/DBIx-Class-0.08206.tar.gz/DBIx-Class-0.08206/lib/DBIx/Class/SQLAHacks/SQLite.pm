package # Hide from PAUSE
  DBIx::Class::SQLAHacks::SQLite;

use base qw( DBIx::Class::SQLMaker::SQLite );

1;
