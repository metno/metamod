package DBICNSTest::RSBase;
use base qw/DBIx::Class::ResultSet/;
1;
