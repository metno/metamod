package DBICNSTest::RSet::C;
use base qw/DBIx::Class::ResultSet/;
1;
