package t::lib::D;
use Class::C3;    
use base ('t::lib::A', 't::lib::E');
1;
