package TestApp::Schema;

# Created by DBIx::Class::Schema::Loader v0.03007 @ 2006-10-18 12:38:33

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_classes;

1;