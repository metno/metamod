package Catalyst::Action::Serializer::Broken;

use Moose;
use namespace::autoclean;

use Bilbo::Baggins;

1;

