package EntryClass;

use base qw( Catalyst::Model::LDAP::Entry );

sub my_method {
    return 1001;
}
1;
