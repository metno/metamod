#ifdef DEBUGMAIN
void prtc(int n, double p[], double q[]);
void prtz(int n,double zr[], double zi[]);
#endif
int cpoly(double opr[], double opi[], int degree,
	   double zeror[], double zeroi[]);

#if !defined(FALSE)
#define FALSE (0)
#endif
#if !defined(TRUE)
#define TRUE (1)
#endif

