# Copyright 2005-2015, Paul Johnson (paul@pjcj.net)

# This software is free.  It is licensed under the same terms as Perl itself.

# The latest version of this software should be available from my homepage:
# http://www.pjcj.net

package PodMod;

use base "Module1";

sub vv { die }
sub ww { die }
sub yy { die }

1

__END__

=head2 vv

vv

=cut
