CREATE TABLE error_test (
    foo VARCHAR(20),
    UNIQUE( foo )
)
