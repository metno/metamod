CREATE TABLE pkless (
    anything varchar(200)
)
