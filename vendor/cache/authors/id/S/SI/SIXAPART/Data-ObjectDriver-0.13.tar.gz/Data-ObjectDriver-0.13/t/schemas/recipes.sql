CREATE TABLE recipes (
  recipe_id INTEGER NOT NULL PRIMARY KEY,
  partition_id SMALLINT,
  title VARCHAR(50)
)
