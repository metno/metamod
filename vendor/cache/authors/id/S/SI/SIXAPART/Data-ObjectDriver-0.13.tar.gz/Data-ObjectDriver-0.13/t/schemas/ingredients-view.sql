CREATE TABLE ingredients (
  id INTEGER NOT NULL,
  name VARCHAR(50),
  quantity SMALLINT,
  PRIMARY KEY (id)
)
