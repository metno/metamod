package AnotherSchemaClass;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;

1;
