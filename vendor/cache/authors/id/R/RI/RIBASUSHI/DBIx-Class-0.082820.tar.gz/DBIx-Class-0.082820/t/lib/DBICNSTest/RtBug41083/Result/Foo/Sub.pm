package DBICNSTest::RtBug41083::Result::Foo::Sub;
use strict;
use warnings;
use base 'DBICNSTest::RtBug41083::Result::Foo';
1;
