package Foo::Plugin::Baz;

1;
