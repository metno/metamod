package TestA;

1;
__END__