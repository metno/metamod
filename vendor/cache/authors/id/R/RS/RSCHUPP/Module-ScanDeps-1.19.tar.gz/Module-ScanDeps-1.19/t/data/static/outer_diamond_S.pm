package outer_diamond_S;

1;
__END__