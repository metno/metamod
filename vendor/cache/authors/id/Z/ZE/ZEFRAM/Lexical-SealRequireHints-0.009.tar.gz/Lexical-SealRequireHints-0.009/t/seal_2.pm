package t::seal_2;

use warnings;
use strict;

10;
