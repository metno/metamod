package # hide from PAUSE
    My::TestSchema;
use warnings;
use strict;
use base qw/DBIx::Class::Schema/;

__PACKAGE__->load_classes;

1;
