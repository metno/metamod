package DBICTest::Schema::NoSuchClass;

## This is purposefully not a real DBIC class
## Used in t/102load_classes.t

1;
